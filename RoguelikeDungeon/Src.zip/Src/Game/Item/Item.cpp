#include"Item.h"
#include"../Object/Player/Player.h"
#include"../Object/ObjectManager.h"
#include <iostream>
#include <vector>

bool Item::Use(ItemUseContext& context) const
{
    //�g�p�����A�C�e���ɂ���ċ�����ς���
    switch (m_Type)
    {
    case ITEM_1:
        context.player.AddHeal(15);
        std::cout << "15��" << std::endl;
        break;

    case ITEM_2:
        context.player.AddMaxHP(5);
        std::cout << "�ő�HP5�A�b�v" << std::endl;
        break;

    case ITEM_3:
        context.player.AddAtk(5);
        std::cout << "�U����5�A�b�v" << std::endl;
        break;

    case ITEM_4:
    {
        std::vector<CObject*> targets =
            context.objectManager.FindObjectsInSameRoom(context.player.GetPos(),context.map);

        for (CObject* object : targets)
        {
            if (object == nullptr)
            {
                continue;
            }

            object->AddDamage(5);
        }

        std::cout << "�G�S�̂�5�_���[�W" << std::endl;

        context.objectManager.DeleteDeadObject();
        break;
    }

    default:
        return false;
    }

    return true;
}