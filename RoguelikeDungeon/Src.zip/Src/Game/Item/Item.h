#pragma once
#include"../Common.h"
#include"../Object/Object.h"
#include<vector>
#include"ItemModelManager.h"
#include"ItemUseContext.h"


// �A�C�e��1���̏��
struct Item
{
    ITEM_TYPE type;

    bool Use(ItemUseContext& context) const;
};

