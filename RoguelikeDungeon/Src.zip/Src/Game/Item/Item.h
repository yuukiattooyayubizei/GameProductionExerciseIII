#pragma once
#include"../Common.h"
#include"ItemUseContext.h"
#include<string>

// �A�C�e��1���̏��
struct Item
{
    ITEM_TYPE m_Type;
    std::string m_Name;

    bool Use(ItemUseContext& context) const;
};

