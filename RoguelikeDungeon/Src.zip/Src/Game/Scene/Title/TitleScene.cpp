#include"TitleScene.h"
#include"math.h"
#include "../../Common.h"
#include "../../../Lib/Input/PadInput.h"
#include "../../../Lib/Sound/sound.h"

//�R���X�g���N�^
CTitleScene::CTitleScene()
{
	m_tagTitleScene = TITLE_SCENE_INIT;
	m_Titlehndl = -1;
}

//�f�X�g���N�^
CTitleScene::~CTitleScene()
{
	Exit();
}

void CTitleScene::Init()
{
	m_tagTitleScene = TITLE_SCENE_INIT;
}

void CTitleScene::Exit()
{
	if (m_Titlehndl != -1)
	{
		DeleteGraph(m_Titlehndl);
		m_Titlehndl = -1;
	}
}

void CTitleScene::Load()
{
	if(m_Titlehndl == -1)
		m_Titlehndl = LoadGraph("../Data/Image/Title/Title.JPG");
}

int CTitleScene::Loop()
{
	int m_ret = 0;

	//��ԑJ�ڂɉ����ċ�����ύX
	switch (m_tagTitleScene)
	{
	case CTitleScene::TITLE_SCENE_INIT:
		//������
		Init();
		m_tagTitleScene = TITLE_SCENE_LOAD;
		break;
	case CTitleScene::TITLE_SCENE_LOAD:
		//���[�h
		Load();
		m_tagTitleScene = TITLE_SCENE_LOOP;
		//BGM��炷
		RequestSound(BGMID_TITLE, DX_PLAYTYPE_BACK);
		break;
	case CTitleScene::TITLE_SCENE_LOOP:
		//����
		if (Step() == 1)m_tagTitleScene = TITLE_SCENE_END;
		break;
	case CTitleScene::TITLE_SCENE_END:
		//�j��
		StopAllSound();
		Exit();
		m_tagTitleScene = TITLE_SCENE_INIT;
		m_ret = 1;
		break;
	default:
		break;
	}

	return m_ret;
}

int CTitleScene::Step()
{
	if(CheckHitKey(KEY_INPUT_J))
		return 1;

	return 0;
}

void CTitleScene::Draw()
{
	//�`�揈��

	DrawFormatString(32, 96, GetColor(255, 255, 255), "J�L�[�ŃX�^�[�g");
}