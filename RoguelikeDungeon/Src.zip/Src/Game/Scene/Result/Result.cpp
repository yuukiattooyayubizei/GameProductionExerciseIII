#include"ResultScene.h"
#include"math.h"
#include "../../Common.h"
#include "../../../Lib/Input/PadInput.h"
#include "../../../Lib/Sound/sound.h"
#include "../../Data/Data.h"


//�R���X�g���N�^
CResultScene::CResultScene()
{
	m_tagResultScene = RESULT_SCENE_INIT;


}

//�f�X�g���N�^
CResultScene::~CResultScene()
{
	Exit();
}

void CResultScene::Init()
{
	m_tagResultScene = RESULT_SCENE_INIT;

}

void CResultScene::Exit()
{

}

void CResultScene::Load()
{
	CData* Data = CData::GetInstance();


}

int CResultScene::Loop()
{

	int m_ret = 0;

	//��ԑJ�ڂɉ����ċ�����ύX
	switch (m_tagResultScene)
	{
	case CResultScene::RESULT_SCENE_INIT:
		//������
		Init();
		m_tagResultScene = RESULT_SCENE_LOAD;
		break;
	case CResultScene::RESULT_SCENE_LOAD:
		//���[�h
		Load();
		m_tagResultScene = RESULT_SCENE_LOOP;
		//BGM��炷
		RequestSound(BGMID_RESULT, DX_PLAYTYPE_BACK);
		break;
	case CResultScene::RESULT_SCENE_LOOP:
		//����
		if (Step() == 1)m_tagResultScene = RESULT_SCENE_END;
		break;
	case CResultScene::RESULT_SCENE_END:
		//�j��
		StopAllSound();
		Exit();
		m_tagResultScene = RESULT_SCENE_INIT;
		m_ret = 1;
		break;
	default:
		break;
	}

	return m_ret;
}

int CResultScene::Step()
{

	if(CheckHitKey(KEY_INPUT_K))
		return 1;

	return 0;
}

void CResultScene::Draw()
{


}