#include"ObjectManager.h"
#include<iostream>
#include"../Scene/Play/PlayScene.h"
#include"Enemy/Enemy1/Enemy1.h"
#include"Enemy/Enemy2/Enemy2.h"
#include"Enemy/Enemy3/Enemy3.h"
#include"Enemy/Enemy4/Enemy4.h"
#include<algorithm>
#include"../../Lib/Input/Input.h"
#include"Player/Player.h"
#include "../UI/Log.h"

void CObjectManager::DeleteDeadObject()
{
    auto newEnd = std::remove_if(m_Object.begin(),m_Object.end(),[this](CObject* object){
        CLog* Log = CLog::GetInstance();
            // �v���C���[�͂����ł͍폜���Ȃ�
            if (object->GetKind() == KIND_PLAYER)
            {
                return false;
            }
            if (!object->GetActive())
            {
                if (object->GetHP() <= 0)
                {
                    std::string rog = "�G���j";
                    Log->AddLog(rog);
                    object->SetActive(false);
                    //�o���l�̕t�^
                    int exp = object->GetAddExp();
                    m_Player->AddExp(exp);
                    rog = std::to_string(exp) + "�̌o���l���l��";
                    Log->AddLog(rog);
                }


                object->Exit();
                delete object;
                return true;
            }
            return false;
        }
    );

    m_Object.erase(newEnd, m_Object.end());
}

CObject* CObjectManager::FindObjectAt(Int2 pos)
{
    for (CObject* object : m_Object)
    {
        if (object == nullptr)
        {
            continue;
        }

        if (!object->GetActive())
        {
            continue;
        }

        if (object->GetPos().x == pos.x &&
            object->GetPos().y == pos.y)
        {
            return object;
        }
    }
    return nullptr;
}

std::vector<CObject*> CObjectManager::FindObjectsInSameRoom(Int2 pos,CMap& map){

    std::vector<CObject*> result;

    int roomNum = map.GetRoomNum(pos);

    if (roomNum == -1)
    {
        return result;
    }

    for (CObject* object : m_Object)
    {
        if (object == nullptr)
        {
            continue;
        }

        if (object->GetKind() == KIND_PLAYER)
        {
            continue;
        }

        if (map.GetRoomNum(object->GetPos()) == roomNum)
        {
            result.push_back(object);
        }
    }

    return result;
}

//�w�肳�ꂽ���W����w�肳�ꂽ����������Ƃ��ɉf��I�u�W�F�N�g��Ԃ�
//isClosestObject��true�Ȃ�A��ԋ߂�������Ԃ�
std::vector<CObject*> CObjectManager::FindObjectsInSeeDirection(Int2 pos, DIRECTION dir, CMap& map, bool isClosestObject) {
    Int2 nextpos = pos;
    Int2 movepos = DirectionToInt2(dir);
    std::vector<CObject*> result;

    for (int i = 0;i < map.GetFieldOfVision(pos, dir);i++) {
        //���̃}�X������
        nextpos = AddInt2(nextpos, movepos);
        //���̃}�X�ɃI�u�W�F�N�g�����邩����
        CObject* target = FindObjectAt(nextpos);

        //�Ȃɂ�������A������Ԃ�l�ɉ�����
        if (target != nullptr)
        {
            result.push_back(target);

            //1�̌����ďI���Ȃ�A�����ŏI���
            if (isClosestObject == true)return result;
        }
    }
    return result;
}

void CObjectManager::ClearEnemy() {
    //�v���C���[�ȊO�̃I�u�W�F�N�g���폜
    auto newEnd = std::remove_if(
        m_Object.begin(),
        m_Object.end(),
        [](CObject* object)
        {
            if (object == nullptr)
            {
                return true;
            }

            if (object->GetKind() != KIND_PLAYER)
            {
                object->Exit();
                delete object;
                return true;
            }

            return false;
        }
    );

    m_Object.erase(newEnd, m_Object.end());
}

void CObjectManager::ClearAll()
{
    for (CObject* object : m_Object)
    {
        if (object == nullptr)
        {
            continue;
        }
        object->Exit();
        delete object;
    }
    m_Object.clear();
}

void CObjectManager::Init() {
    for (CObject* obj : m_Object)
    {
        if (obj != nullptr)
        {
            obj->Init();
        }
    }

    // �O�̂��ߑO��̎c�������
    ClearAll();
  //  m_PlayerTurn = true;
    m_EnemySpawnWait = ENEMY_SPAWN_WAIT;
    m_Player = {};
    m_PlayMode = MODE_PLAY;
}

void CObjectManager::Load() {
    for (CObject* obj : m_Object)
    {
        if (obj != nullptr)
        {
            obj->Load();
        }
    }
}

PlayerAction CObjectManager::PlayerStep(int floor) {
    CMap* Map = CMap::GetInstance();
    CLog* Log = CLog::GetInstance();

        //�A�C�e���I���Ɉڍs
    if (IsInputTrg(KEY_K))
    {
        m_PlayMode = MODE_ITEM_MENU;
        Map->SetSelectItemIndex();
        Map->SetItemPage();
        int InventorySize = m_Player->GetInventorySize();
        Map->UpDateItemMenu(InventorySize);
        return ACTION_ITEM_MENU;
    }
        //�����݂���(�Ȃɂ����Ȃ�)
    if (IsInputTrg(KEY_F))
    {
        return ACTION_END;
    }

    //Z�L�[�Ń����_���G����
    if (IsInputTrg(KEY_Z))
        CreateEnemy(floor);
    //X�L�[�Ń����_���A�C�e������
    if (IsInputTrg(KEY_X))
    {
        int i = GetRand(ITEM_NUM);
        Item item = {};
        switch (i)
        {
        case 0:
            item.m_Type = ITEM_1;
            m_Player->AddItem(item);
            break;
        case 1:
            item.m_Type = ITEM_2;
            m_Player->AddItem(item);
            break;
        case 2:
            item.m_Type = ITEM_3;
            m_Player->AddItem(item);
            break;
        case 3:
            item.m_Type = ITEM_4;
            m_Player->AddItem(item);
            break;
        default:
            break;
        }
    }

    //�I�u�W�F�N�g��������}�X��T��
    CanMove C = GetCanMove(m_Player->GetPos());

    //�v���C���[����������
    if (m_Player->GetKind() == KIND_PLAYER)
    {
        m_Player->Step(C, m_Player->GetPos());

        //�v���C���[���ړ����Ă�����
        if (m_Player->GetIsMove() == true)
        {
            Int2 move = DirectionToInt2(m_Player->GetDirection());
            Int2 NextPos = AddInt2(m_Player->GetPos(), move);
            //�ړ���������ɃI�u�W�F�N�g�����Ȃ����`�F�b�N
            int ObjectNum = CollisionObject(NextPos);
            TILE NextTile = Map->GetTile(NextPos);
            if (ObjectNum == -1)
            {
                if (NextTile == TILE_ROOM || NextTile == TILE_CORRIDOR || NextTile == TILE_CORRIDOR_ADJACENT_ROOM)
                {
                    //�������Ȃ��Ȃ�
                    //�v���C���[���ړ�������
                    m_Player->AddPos(move);
                    m_Player->SetMove(false);
                }
            }
            else
            {
                // ����������Ȃ����ɂ����ɍU��
                CObject* target = FindObjectAt(NextPos);

                m_CombatResolver.PlayerAttack(*m_Player,*target);

            }

            //�ړ���̃A�C�e��������
            Item item = {};
            item.m_Type = Map->IsItemExist(m_Player->GetPos());

            //�A�C�e������������
            if (item.m_Type != ITEM_NON)
            {
                //���̃A�C�e�����C���x���g���ɓ����
                if (m_Player->AddItem(item))
                    //���ꂽ�A�C�e��������
                    Map->EraseItem(m_Player->GetPos());
                else {
                    std::string rog = "�C���x���g�����܂񂽂�";
                    Log->AddLog(rog);
                }
            }
            return ACTION_END;
        }

    }


    //����ł�G�̏���
    DeleteDeadObject();

   
    return ACTION_NON;
}

void CObjectManager::EnemyStep(int floor) {
    CMap* Map = CMap::GetInstance();
    CLog* Log = CLog::GetInstance();

    // �v���C���[�s���̌�
    for (CObject* object : GetObjects())
    {
        if (object == nullptr)
        {
            continue;
        }

        if (!object->GetActive())
        {
            continue;
        }

        // �v���C���[�ȊO�𓮂���
        if (object->GetKind() != KIND_PLAYER)
        {
            // �I�u�W�F�N�g��������}�X��T��
            CanMove C = GetCanMoveEnemy(object->GetPos());

            object->Step(C, m_Player->GetPos());

            // �G���ړ����Ă�����
            if (object->GetDirection() != DIRECTION_NON)
            {
                Int2 move = DirectionToInt2(object->GetDirection());
                Int2 NextPos = AddInt2(object->GetPos(), move);

                // �ړ���ɃI�u�W�F�N�g�����邩�`�F�b�N
                CObject* target = FindObjectAt(NextPos);

                TILE NextTile = Map->GetTile(NextPos);

                //�ړ���ɃI�u�W�F�N�g�����Ȃ���
                if (target == nullptr)
                {
                    if (NextTile == TILE_ROOM || NextTile == TILE_CORRIDOR || NextTile == TILE_CORRIDOR_ADJACENT_ROOM)
                    {
                        // �������Ȃ��Ȃ�ړ�
                        object->AddPos(move);
                    }
                }
                else
                {
                    // �v���C���[������Ȃ�U��
                    if (target->GetKind() == KIND_PLAYER)
                    {
                        int damage = object->GetAtk();

                        m_CombatResolver.EnemyAttack(*m_Player, damage);
                    }
                }
            }
        }
    }

    //�G���o������
    //�G���o���܂ł̃J�E���g��������
    m_EnemySpawnWait--;
    if (m_EnemySpawnWait <= 0)
    {
        //0�ɂȂ�����G���o���ăJ�E���g�����Z�b�g
        m_EnemySpawnWait = ENEMY_SPAWN_WAIT;
        CreateEnemy(floor);
    }
    
    return;
}

void CObjectManager::Draw() {
    for (CObject* obj : m_Object)
    {
        if (obj != nullptr)
        {
            obj->Draw();
        }
    }
}

int CObjectManager::CollisionObject(const Int2& pos) const
{
    int ret = 0;

    for (CObject* obj : m_Object)
    {
        if (obj == nullptr)
        {
            ret++;
            continue;
        }

        if (!obj->GetActive())
        {
            ret++;
            continue;
        }

        if (obj->GetPos().x == pos.x && obj->GetPos().y == pos.y)
        {
            return ret;
        }

        ret++;
    }

    return -1;
}

bool CObjectManager::CollisionAll(Int2 pos)
{
    CMap* Map = CMap::GetInstance();
    if (CollisionObject(pos) != -1)return true;
    if (Map->CollisionItem(pos) == true)return true;
    if (Map->CollisionStairs(pos) == true)return true;

    return false;
}

Int2 CObjectManager::FindSpawnPos()
{
    CMap* Map = CMap::GetInstance();
    for (int i = 0; i < RETRY_MAX; ++i)
    {
        Int2 pos = Map->GetNotHerePlayerRoomPos(m_Player->GetPos());

        if (!CollisionAll(pos))
        {
            return pos;
        }
    }
    return { -1, -1 };
}

CEnemy* CObjectManager::CreateRandomEnemy(int floor) {

    int enemyType = GetRand(1);
    if (floor <= 3)
        ;
    else  if (floor <= 7)
        enemyType += 1;
    else
        enemyType += 2;

    switch (enemyType) {
    case 0:     return new CEnemy1(&m_EnemyModelManager);
    case 1:     return new CEnemy2(&m_EnemyModelManager);
    case 2:     return new CEnemy3(&m_EnemyModelManager);
    case 3:     return new CEnemy4(&m_EnemyModelManager);
    default:    return new CEnemy1(&m_EnemyModelManager);
    }
}

void CObjectManager::CreateEnemy(int floor, int CreateNum)
{
    for (int i = 0; i < CreateNum; i++)
    {
        Int2 pos = FindSpawnPos();

        CEnemy* enemy = CreateRandomEnemy(floor);

        enemy->Init();
        enemy->SetPos(pos);

        std::cout << pos.x << "," << pos.y << "�ɓG�𐶐�" << std::endl;

        AddObject(enemy);
    }
}

//�v���C���[�Ɠ��������ɂ���Object��Ԃ�
std::vector<CObject*> CObjectManager::FindLiveTogetherObject(Int2 i) {
    CMap* Map = CMap::GetInstance();
    std::vector<CObject*> res;

    //�v���C���[�̕����ԍ����擾
    int PlayerRoomNum = Map->GetRoomNum(i);
    //-1(�����ɂ��Ȃ�)�̏ꍇ�I��
    if (PlayerRoomNum == -1)return {};


    for (CObject* object : GetObjects()) {
        if (object->GetKind() == KIND_PLAYER) {
            continue;
        }

        if (Map->GetRoomNum(object->GetPos()) == PlayerRoomNum) {
            res.push_back(object);
        }
    }

    return res;
}

CanMove CObjectManager::GetCanMoveEnemy(Int2 pos)
{
    CMap* Map = CMap::GetInstance();
    Int2 v = pos;
    CanMove C;
    Int2 NextPos{};
    NextPos.x = static_cast<int>(v.x);
    NextPos.y = static_cast<int>(v.y);

    //��U�S��true��
    C.Down = true, C.Up = true, C.Left = true, C.Right = true;
    //�}�X�ڂ̒[���ƃ}�X�̊O���̕����ɂ͍s���Ȃ�
    if (NextPos.x <= 0)
        C.Left = false;
    if (NextPos.x >= MAP_X - 1)
        C.Right = false;
    if (NextPos.y <= 0)
        C.Up = false;
    if (NextPos.y >= MAP_Y - 1)
        C.Down = false;

    //�㉺���E�̃}�X�����Ēʂ��}�X�łȂ���΍s���Ȃ�
    //���ł�false�Ȃ猩��K�v���Ȃ�
    TILE t = {};
    if (C.Left == true)
    {
        NextPos.x--;
        t = Map->GetTile(NextPos);
        if (t == TILE_WALL)
            C.Left = false;


        NextPos.x++;
        if (GetAheadMoveObject(NextPos, DIRECTION_LEFT) == KIND_ENEMY)
            C.Left = false;
    }
    if (C.Right == true)
    {
        NextPos.x++;
        t = Map->GetTile(NextPos);
        if (t == TILE_WALL)
            C.Right = false;
        NextPos.x--;
        if (GetAheadMoveObject(NextPos, DIRECTION_RIGHT) == KIND_ENEMY)
            C.Right = false;
    }
    if (C.Up == true)
    {
        NextPos.y--;
        t = Map->GetTile(NextPos);
        if (t == TILE_WALL)
            C.Up = false;
        NextPos.y++;
        if (GetAheadMoveObject(NextPos, DIRECTION_UP) == KIND_ENEMY)
            C.Up = false;
    }
    if (C.Down == true)
    {
        NextPos.y++;
        t = Map->GetTile(NextPos);
        if (t == TILE_WALL)
            C.Down = false;
        NextPos.y--;
        if (GetAheadMoveObject(NextPos, DIRECTION_DOWN) == KIND_ENEMY)
            C.Down = false;
    }

    return C;
}

ObjectKind CObjectManager::GetAheadMoveObject(Int2 pos, DIRECTION dir)
{
    ObjectKind ret = KIND_NON;
    Int2 p = pos;
    int id = -1;

    switch (dir)
    {
    case DIRECTION_UP:
        p.y--;
        break;
    case DIRECTION_DOWN:
        p.y++;
        break;
    case DIRECTION_LEFT:
        p.x--;
        break;
    case DIRECTION_RIGHT:
        p.x++;
        break;
    default:
        return KIND_NON;
    }

    id = CollisionObject(p);

    if (id != -1)
    {
        ret = GetKind(id);
    }

    return ret;
}

ObjectKind CObjectManager::GetKind(int id)const {
    //�I�u�W�F�N�g�͈̔͊O�Ȃ�NON��Ԃ�
    if (id < 0 || id >= static_cast<int>(m_Object.size())) return KIND_NON;
    if (m_Object[id] == nullptr) return KIND_NON;
    
    return m_Object[id]->GetKind();
}

void CObjectManager::CreatePlayer() {

    m_Player = nullptr;

    m_Player = new CPlayer();
    m_Player->Init();

    m_Player->Load();

    AddObject(m_Player);
}

void CObjectManager::CreatePlayerPos() {
    Int2 v = FindSpawnPos();
    m_Player->SetPos(v);
}