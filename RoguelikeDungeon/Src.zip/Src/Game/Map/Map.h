#pragma once
#include<vector>
#include"../Common.h"
#include"../Item/FieldItem/FieldItem.h"
#include"Room/Room.h"
#include"MapCommon.h"
#include"MapData/MapData.h"
#include"FieldItemManager/FieldItemManager.h"
#include"MapCreate/MapCreate.h"
#include"ItemMenu/ItemMenu.h"
#include"MapDraw/MapDraw.h"

class CMap {
private:
	static CMap* m_Instance;
public:
	static CMap* GetInstance();
	static void DeleteInstance();
private:
	CMapData m_MapData;
	CMapDraw m_MapDraw;
	CMapCreate m_MapCreate;
	CItemMenu m_ItemMenu;
	CFieldItemManager m_FieldItemManager;
public:
	CMap() { Init(); }

	//----------------------------------------------
	// ��{����
	//----------------------------------------------

	void Init();
	void Load();
	void Draw(Int2 playerPos);
	void Exit();

	// �S������
	void DeleteAll();
	//�K�w�𐶐�
	void CreateFloor();

	//----------------------------------------------
	// �擾�n
	//----------------------------------------------

	Int2 GetStairsPos() const { return m_MapData.GetStairsPos(); }									//�K�i�̍��W��Ԃ�
	TILE GetTile(Int2 pos) { return m_MapData.GetTile(pos); }										//�w�肳�ꂽ���W�̃^�C���̎�ނ�Ԃ�
	int GetRoomID(Int2 pos) { return m_MapData.GetRoomID(pos); }									//���W�̕�����ID��Ԃ�
	Int2 GetNotHerePlayerRoomPos(Int2 PlPos) { return m_MapData.GetNotHerePlayerRoomPos(PlPos); }	//�����̒��̃v���C���[�����Ȃ������_���ȍ��W���擾
	int GetRoomNum() { return m_MapData.GetRoomNum(); }												//�����̐����擾

	void SetSelectItemIndex(int i = 0) { m_ItemMenu.SetSelectItemIndex(i); }
	void SetItemPage(int i = 0) { m_ItemMenu.SetItemPage(i); }
	int GetFieldOfVision(Int2 i, DIRECTION dir) { return m_MapData.GetFieldOfVision(i,dir); }
	std::vector<int> CalcRoomDistance(int startRoom) const{return m_MapData.CalcRoomDistance(startRoom);}
	std::vector<int> FindRoomRoute(int startRoom,int goalRoom) const{return m_MapData.FindRoomRoute(startRoom,goalRoom);}
	const RoomLink* FindRoomLink(int currentRoomID, int nextRoomID) { return m_MapData.FindRoomLink(currentRoomID,nextRoomID); }
	const RoomLink* FindRoomLinkByPosition(const Int2& position) const { return m_MapData.FindRoomLinkByPosition(position); }

	//----------------------------------------------
	// ����n
	//----------------------------------------------

	// �L���Ƃ��Ԃ��Ă��邩�𔻒�
	bool CollisionStairs(Int2 i) { return m_MapData.CollisionStairs(i); }

	//----------------------------------------------
	// �A�C�e���֘A
	//----------------------------------------------

	void CreateItem(int CreateNum, int x = -1, int y = -1) { m_FieldItemManager.CreateItem(m_MapData, CreateNum, x, y); }
	// �w�肵�����W�̃A�C�e��������
	void EraseItem(Int2 pos) { m_FieldItemManager.EraseItem(pos); }
	// �A�C�e�����������W�ɂ��邩�`�F�b�N
	bool CollisionItem(Int2 i) { return m_FieldItemManager.CollisionItem(i); }
	void DrawItemMenu(const std::vector<Item>& Inventory) { m_ItemMenu.DrawItemMenu(Inventory); }
	int StepItemMenu(int itemCount) { return m_ItemMenu.StepItemMenu(itemCount); }
	void UpDateItemMenu(int itemCount) { m_ItemMenu.UpdatePage(itemCount); }
	ITEM_TYPE IsItemExist(Int2 i) { return m_FieldItemManager.IsItemExist(i); }
};