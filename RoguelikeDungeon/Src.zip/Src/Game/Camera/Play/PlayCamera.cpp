#include<DxLib.h>
#include"PlayCamera.h"

PlayerCamera::PlayerCamera()
{
	//������
	Init();
}

PlayerCamera::~PlayerCamera()
{

}

void PlayerCamera::Init()
{
	//�Ƃ肠�����S��0������
	memset(&m_camPos, 0, sizeof(VECTOR));
	memset(&m_targetPos, 0, sizeof(VECTOR));
	memset(&m_upVec, 0, sizeof(VECTOR));

	m_upVec.y = 1.0f;
}

void PlayerCamera::Init(VECTOR camPos, VECTOR targetPos, VECTOR upVec)
{
	//������
	m_camPos = camPos;
	m_targetPos = targetPos;
	m_upVec = upVec;
}

void PlayerCamera::Step(VECTOR focus, float rotY, float spd, bool zoomin)
{
	m_targetPos = focus;
	m_targetPos.y = 0.0f;

	m_camPos = VGet(focus.x, 1400.0f, focus.z);

	m_upVec = VGet(0.0f, 0.0f, -1.0f);
}

void PlayerCamera::UpDate()
{
	//�J�����̃A�b�v�f�[�g
	SetCameraPositionAndTargetAndUpVec(m_camPos, m_targetPos, m_upVec);
}

void PlayerCamera::SetNearFar(float n, float f)
{
	//�j�A�t�@�[���Z�b�g
	SetCameraNearFar(n, f);
}