#include"Sound.h"
#include<DxLib.h>

static const char* SOUND_PATH[SOUND_NUM] = {
	"../Data/Musics/BGM01.mp3",
	"../Data/Musics/BGM02.mp3",
	"../Data/Musics/BGM03.mp3",
	"../Data/Musics/SE01.mp3",
};

SOUND_MANAGER g_soundManager;

//�f�[�^��������
void InitSound()
{
	for (int i = 0; i < SOUND_NUM; i++)
	{
		g_soundManager.m_hndl[i] = -1;
	}
}
//�摜�f�[�^�����[�h
void LoadSound()
{
	for (int i = 0; i < SOUND_NUM; i++)
	{
		if (g_soundManager.m_hndl[i] == -1)
		{
			g_soundManager.m_hndl[i] = LoadSoundMem(SOUND_PATH[i]);
		}
	}
}

//�I���O�ɍs��
void ExitSound()
{
	for (int i = 0; i < SOUND_NUM; i++)
	{
		if (g_soundManager.m_hndl[i] != -1)
		{
			DeleteSoundMem(g_soundManager.m_hndl[i]);
		}
	}
}

void RequestSound(int soundID, int type)
{
	PlaySoundMem(g_soundManager.m_hndl[soundID], type);
}

void StopSound(int soundID)
{
	StopSoundMem(g_soundManager.m_hndl[soundID]);
}

void StopAllSound()
{
	for (int i = 0; i < SOUND_NUM; i++)
	{
		StopSound(i);
	}
}