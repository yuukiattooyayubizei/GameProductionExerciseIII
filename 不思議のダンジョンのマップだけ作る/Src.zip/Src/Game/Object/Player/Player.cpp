#include"Player.h"
#include "../../../lib/Input/input.h"
#include "../../Common.h"
#include "../../Item/Item.h"
#include <iostream>



CPlayer::~CPlayer(){
}

void CPlayer::Init(){
	m_Pos.x = 0;
	m_Pos.y = 0;
	m_Kind = KIND_PLAYER;
	m_HP = HP_MAX;
	m_MaxHP = HP_MAX;
}

void CPlayer::Load() {
}

void CPlayer::Step(CanMove canmove) {
	m_Direction = DIRECTION_NON;

	if (IsInputTrg(KEY_W) && canmove.Up == true) {
		m_Pos.y--;
		m_Direction = DIRECTION_UP;
	}
	if (IsInputTrg(KEY_S) && canmove.Down == true) {
		m_Pos.y++;
		m_Direction = DIRECTION_DOWN;
	}
	if (IsInputTrg(KEY_A) && canmove.Left == true) {
		m_Pos.x--;
		m_Direction = DIRECTION_LEFT;
	}
	if (IsInputTrg(KEY_D) && canmove.Right == true) {
		m_Pos.x++;
		m_Direction = DIRECTION_RIGHT;
	}
}

void CPlayer::Draw() {
	DrawFormatString(32, 32, GetColor(255, 255, 255), "posx = %d", m_Pos.x);
	DrawFormatString(32, 64, GetColor(255, 255, 255), "posy = %d", m_Pos.y);
	DrawFormatString(32, 96, GetColor(255, 255, 255), "HP = %d / %d", m_HP, m_MaxHP);


	//�v���C���[�̕`��
	int centerX = 8 + m_Pos.x * 16;
	int centerY = 8 + m_Pos.y * 16;
	DrawBox(centerX + 4, centerY + 4, centerX - 4, centerY - 4, GetColor(255, 255, 255), TRUE);
}

void CPlayer::Exit() {

}

bool CPlayer::AddItem(const Item& item)
{
	// �ő吔�ȏ�͎��ĂȂ�
	if (IsInventoryFull())
		return false;

	// �����A�C�e���ł��܂Ƃ߂��ɁA���̂܂�1�ǉ�����
	m_Inventory.push_back(item);

	std::cout << "�A�C�e���ǉ�����" << std::endl;
	switch (item.type)
	{
	case ITEM_1:
		std::cout << "�A�C�e��1" << std::endl;
		break;
	case ITEM_2:
		std::cout << "�A�C�e��2" << std::endl;
		break;
	case ITEM_3:
		std::cout << "�A�C�e��3" << std::endl;
		break;
	case ITEM_4:
		std::cout << "�A�C�e��4" << std::endl;
		break;
	default:
		break;
	}

	return true;
}

bool CPlayer::IsInventoryFull() const
{
	return static_cast<int>(m_Inventory.size()) >= INVENTORY_MAX;
}

void CPlayer::DrawInventoryDebug()
{
	int x = 820;
	int y = 20;

	DrawString(x, y, "Inventory", GetColor(255, 255, 255));
	y += 20;

	for (int i = 0; i < static_cast<int>(m_Inventory.size()); i++)
	{
		DrawFormatString(
			x,
			y,
			GetColor(255, 255, 255),
			"%02d: %s",
			i,
			/*GetItemName(m_Inventory[i].type)*/
			"a"
		);

		y += 20;
	}
}